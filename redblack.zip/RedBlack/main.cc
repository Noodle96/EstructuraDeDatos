#include<iostream>
using namespace std;

#include "redBlack.h"
int main(){

    RedBlack<int> rb;
    int v;
    for(int e =  1; e < 52; e++){
        // cout << e << endl;
        // cin >> v;
         rb.Add(e);
    }
    rb.printSVG();




    return 0;
}
